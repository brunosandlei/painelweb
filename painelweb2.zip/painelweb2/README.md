Painel Web
==========

Novo SGA Painel escrito em HTML5 e Javascript.

Compatível com versões a partir da 1.0.0
